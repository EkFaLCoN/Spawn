package net.mrwqlf.spawnsistemi;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.block.data.type.Lantern;
import org.bukkit.block.data.type.Leaves;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Doğal görünümlü spawn adası: tepeli çim arazi, meydan + çeşme, patikalar, Zindan Kapısı, pazar, Kasalar köşkü,
 * kamp ateşi, gözlem kulesi, iskeleli gölet, ağaçlar, çiçekler. Tamamen koddan üretilir (tohum aynıysa aynı sonuç).
 * Yer seviyesi y=64, merkez (0,0). Dünya sınırı ±42; ada bunun çok ötesine uzanır (manzara).
 */
final class SpawnInsa {
    private static final int Y0 = 64;
    private static final int TARA = 72;
    private static final int YOK = Integer.MIN_VALUE;
    private static final double PX = -22, PZ = 22, PR = 8.5;      // gölet

    private record Pad(double x, double z, double r) {
    }

    private record Seg(double ax, double az, double bx, double bz, double faz) {
        double uzun() {
            return Math.hypot(bx - ax, bz - az);
        }
    }

    private final SpawnSistemi pl;
    private final World w;
    private final long tohum;
    private final Random rnd;
    private final List<Pad> pads = List.of(
            new Pad(0, 0, 16), new Pad(0, -36, 9), new Pad(34, 0, 10),
            new Pad(0, 34, 9), new Pad(24, -24, 6), new Pad(-26, -26, 6.5));
    private final List<Seg> yollar;
    private final List<int[]> agaclar = new ArrayList<>();

    SpawnInsa(SpawnSistemi pl, World w, long tohum) {
        this.pl = pl;
        this.w = w;
        this.tohum = tohum;
        this.rnd = new Random(tohum);
        yollar = List.of(
                new Seg(0, -14, 0, -33, 0.3), new Seg(0, 14, 0, 31, 1.1), new Seg(14, 0, 30, 0, 2.0),
                new Seg(-14, 0, -36, 0, 2.9), new Seg(10, -10, 22, -22, 3.7), new Seg(-10, -10, -24, -24, 4.4),
                new Seg(-10, 10, -18, 19, 5.2));
    }

    // ============================================================ gürültü / yükseklik

    private double hash(int x, int z) {
        long h = x * 374761393L + z * 668265263L + tohum * 1274126177L;
        h = (h ^ (h >>> 13)) * 1274126177L;
        h ^= h >>> 16;
        return (h & 0xFFFF) / 65535.0;
    }

    private double vn(double x, double z) {
        int x0 = (int) Math.floor(x), z0 = (int) Math.floor(z);
        double fx = x - x0, fz = z - z0;
        fx = fx * fx * (3 - 2 * fx);
        fz = fz * fz * (3 - 2 * fz);
        double a = hash(x0, z0), b = hash(x0 + 1, z0), c = hash(x0, z0 + 1), d = hash(x0 + 1, z0 + 1);
        return (a + (b - a) * fx) * (1 - fz) + (c + (d - c) * fx) * fz;
    }

    private double gurultu(int x, int z) {
        return vn(x / 13.0, z / 13.0) * 0.65 + vn(x / 5.5, z / 5.5) * 0.35;
    }

    private static double yumusak(double a, double b, double v) {
        double t = Math.max(0, Math.min(1, (v - a) / (b - a)));
        return t * t * (3 - 2 * t);
    }

    private double kenarR(int x, int z) {
        double a = Math.atan2(z, x);
        return 66 + 5 * (vn(Math.cos(a) * 2.2 + 40, Math.sin(a) * 2.2 + 40) - 0.5) * 2;
    }

    private boolean yolda(double x, double z) {
        for (Seg s : yollar) {
            double dx = s.bx - s.ax, dz = s.bz - s.az, l2 = dx * dx + dz * dz;
            double t = ((x - s.ax) * dx + (z - s.az) * dz) / l2;
            if (t < -0.02 || t > 1.02) continue;
            double l = Math.sqrt(l2);
            double nx = -dz / l, nz = dx / l;
            double sap = 1.8 * Math.sin(t * 6.0 + s.faz) * Math.min(1, Math.min(t, 1 - t) * 6);
            double px = s.ax + dx * t + nx * sap, pz = s.az + dz * t + nz * sap;
            if (Math.hypot(x - px, z - pz) <= 1.6) return true;
        }
        return false;
    }

    private boolean padYakin(double x, double z, double pay) {
        for (Pad p : pads) if (Math.hypot(x - p.x, z - p.z) < p.r + pay) return true;
        return Math.hypot(x - PX, z - PZ) < PR + pay;
    }

    int zemin(int x, int z) {
        double d = Math.hypot(x, z);
        double er = kenarR(x, z);
        if (d > er) return YOK;
        double tepe = (gurultu(x, z) - 0.5) * 2 * 2.6;
        double f = 1;
        for (Pad p : pads) f = Math.min(f, yumusak(p.r, p.r + 7, Math.hypot(x - p.x, z - p.z)));
        double pd = Math.hypot(x - PX, z - PZ);
        f = Math.min(f, yumusak(PR, PR + 5, pd));
        if (yolda(x, z)) f *= 0.35;
        double h = Y0 + tepe * f;
        if (pd < PR) h -= (1 - pd / PR) * 5.5;
        if (d > er - 9) h -= (d - (er - 9)) * 0.4;
        return (int) Math.round(h);
    }

    // ============================================================ blok yardımcıları

    private void set(int x, int y, int z, Material m) {
        w.getBlockAt(x, y, z).setType(m, false);
    }

    /** Fizikli yerleştirme: çit/duvar birbirine bağlanır. */
    private void setP(int x, int y, int z, Material m) {
        w.getBlockAt(x, y, z).setType(m, true);
    }

    private void set(int x, int y, int z, BlockData d) {
        w.getBlockAt(x, y, z).setBlockData(d, false);
    }

    private BlockData merdiven(Material m, BlockFace yon) {
        BlockData b = Bukkit.createBlockData(m);
        if (b instanceof Directional dr) dr.setFacing(yon);
        return b;
    }

    private BlockData fener(Material m, boolean asili) {
        BlockData b = Bukkit.createBlockData(m);
        if (b instanceof Lantern l) l.setHanging(asili);
        return b;
    }

    private BlockData yaprak(Material m) {
        BlockData b = Bukkit.createBlockData(m);
        if (b instanceof Leaves l) l.setPersistent(true);
        return b;
    }

    private static BlockFace yonVer(double dx, double dz) {
        return Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? BlockFace.EAST : BlockFace.WEST) : (dz > 0 ? BlockFace.SOUTH : BlockFace.NORTH);
    }

    // ============================================================ kolon (arazi)

    private Material meydanBlok(double d, int x, int z) {
        if (d <= 6) return Material.STONE_BRICKS;
        if (d <= 9.5) return Math.floorMod(x + z, 2) == 0 ? Material.POLISHED_ANDESITE : Material.SMOOTH_STONE;
        if (d <= 12) {
            double r = rnd.nextDouble();
            return r < 0.2 ? Material.MOSSY_STONE_BRICKS : r < 0.35 ? Material.CRACKED_STONE_BRICKS : Material.STONE_BRICKS;
        }
        return Material.POLISHED_ANDESITE;
    }

    private Material yolBlok() {
        double r = rnd.nextDouble();
        return r < 0.78 ? Material.DIRT_PATH : r < 0.9 ? Material.GRAVEL : Material.COARSE_DIRT;
    }

    private void kolon(int x, int z) {
        int s = zemin(x, z);
        if (s == YOK) return;
        double d = Math.hypot(x, z);
        double er = kenarR(x, z);
        int alt = Y0 - (int) Math.min(40, 5 + (er - d) * 0.6);
        double pd = Math.hypot(x - PX, z - PZ);
        boolean gol = pd < PR;
        Material ust;
        if (d <= 14.5) ust = meydanBlok(d, x, z);
        else if (d <= 16 && rnd.nextBoolean()) ust = yolBlok();
        else if (yolda(x, z)) ust = yolBlok();
        else if (gol && s <= 62) ust = rnd.nextDouble() < 0.2 ? Material.CLAY : Material.SAND;
        else if (gol && s == 63 && pd > PR - 2.5) ust = Material.SAND;
        else ust = Material.GRASS_BLOCK;
        for (int y = alt; y <= s; y++) {
            int derin = s - y;
            Material m;
            if (derin == 0) m = ust;
            else if (derin <= 3) m = (ust == Material.SAND || ust == Material.CLAY) ? Material.SAND : (rnd.nextDouble() < 0.1 ? Material.COARSE_DIRT : Material.DIRT);
            else {
                double r = rnd.nextDouble();
                m = r < 0.06 ? Material.ANDESITE : r < 0.09 ? Material.DIORITE : r < 0.11 ? Material.GRAVEL : Material.STONE;
            }
            set(x, y, z, m);
        }
        // gölet suyu: yüzey 63'ün altındaysa 63'e kadar su
        if (gol && s < 63) for (int y = s + 1; y <= 63; y++) set(x, y, z, Material.WATER);
        // üst süs
        if (ust == Material.GRASS_BLOCK && d > 16 && !padYakin(x, z, 1.5) && !yolda(x, z)) {
            double r = rnd.nextDouble();
            if (r < 0.13) set(x, s + 1, z, Material.SHORT_GRASS);
            else if (r < 0.165) {
                Material[] cic = {Material.DANDELION, Material.POPPY, Material.CORNFLOWER, Material.AZURE_BLUET, Material.OXEYE_DAISY, Material.ALLIUM};
                set(x, s + 1, z, cic[rnd.nextInt(cic.length)]);
            } else if (r < 0.172) set(x, s + 1, z, Material.FERN);
        }
    }

    // ============================================================ yapılar

    private void cesme() {
        for (int x = -5; x <= 5; x++)
            for (int z = -5; z <= 5; z++) {
                double d = Math.hypot(x, z);
                if (d <= 3.2) {
                    set(x, Y0, z, Material.WATER);
                    set(x, Y0 - 1, z, Material.STONE_BRICKS);
                } else if (d <= 4.5) {
                    set(x, Y0, z, Material.STONE_BRICKS);
                    set(x, Y0 + 1, z, Material.STONE_BRICK_SLAB);
                }
            }
        set(0, Y0, 0, Material.CHISELED_STONE_BRICKS);
        set(0, Y0 + 1, 0, Material.CHISELED_STONE_BRICKS);
        set(0, Y0 + 2, 0, Material.STONE_BRICK_WALL);
        set(0, Y0 + 3, 0, Material.SEA_LANTERN);
    }

    private void direk(int x, int z) {
        int s = zemin(x, z);
        if (s == YOK) return;
        for (int y = 1; y <= 3; y++) setP(x, s + y, z, Material.OAK_FENCE);
        set(x, s + 4, z, fener(Material.LANTERN, false));
    }

    private void meydanSusu() {
        for (int k = 0; k < 8; k++) {
            double a = Math.toRadians(k * 45 + 22.5);
            direk((int) Math.round(Math.cos(a) * 13.2), (int) Math.round(Math.sin(a) * 13.2));
            // bank (merkeze bakar)
            int bx = (int) Math.round(Math.cos(a) * 10.8), bz = (int) Math.round(Math.sin(a) * 10.8);
            set(bx, Y0 + 1, bz, merdiven(Material.OAK_STAIRS, yonVer(-bx, -bz)));
        }
        // çiçeklikler
        for (int k = 0; k < 4; k++) {
            double a = Math.toRadians(45 + 90 * k);
            int cx = (int) Math.round(Math.cos(a) * 8.0), cz = (int) Math.round(Math.sin(a) * 8.0);
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++) {
                    set(cx + dx, Y0, cz + dz, Material.PODZOL);
                    double r = rnd.nextDouble();
                    if (dx == 0 && dz == 0) set(cx, Y0 + 1, cz, Material.FLOWERING_AZALEA);
                    else if (r < 0.5) {
                        Material[] c2 = {Material.RED_TULIP, Material.PINK_TULIP, Material.ALLIUM, Material.CORNFLOWER, Material.POPPY};
                        set(cx + dx, Y0 + 1, cz + dz, c2[rnd.nextInt(c2.length)]);
                    }
                }
        }
    }

    private void kapi() {
        int cz = -36;
        for (int x = -6; x <= 6; x++)
            for (int z = cz - 3; z <= cz + 3; z++) set(x, Y0, z, Material.POLISHED_DEEPSLATE);
        for (int[] sx : new int[][]{{-5, -4}, {4, 5}}) {
            for (int x = sx[0]; x <= sx[1]; x++)
                for (int z = cz - 1; z <= cz; z++)
                    for (int y = 1; y <= 7; y++)
                        set(x, Y0 + y, z, y % 3 == 1 ? Material.POLISHED_DEEPSLATE : Material.DEEPSLATE_BRICKS);
        }
        for (int x = -5; x <= 5; x++)
            for (int z = cz - 1; z <= cz; z++) {
                set(x, Y0 + 8, z, Material.DEEPSLATE_BRICKS);
                set(x, Y0 + 9, z, Material.CHISELED_DEEPSLATE);
            }
        for (int x = -6; x <= 6; x++)
            for (int z = cz - 2; z <= cz + 1; z++) set(x, Y0 + 10, z, Material.DEEPSLATE_BRICK_SLAB);
        for (int sx : new int[]{-6, 6}) for (int y = 1; y <= 3; y++) for (int z = cz - 1; z <= cz; z++) setP(sx, Y0 + y, z, Material.DEEPSLATE_BRICK_WALL);
        for (int sx : new int[]{-3, 3}) {
            set(sx, Y0 + 7, cz - 1, fener(Material.SOUL_LANTERN, true));
            set(sx, Y0 + 1, cz + 2, Material.SOUL_CAMPFIRE);
        }
    }

    private void pazar() {
        int[] zs = {-6, 0, 6};
        Material[] renk = {Material.RED_WOOL, Material.LIGHT_BLUE_WOOL, Material.ORANGE_WOOL};
        for (int x = 30; x <= 38; x++)
            for (int z = -9; z <= 9; z++) {
                double r = rnd.nextDouble();
                set(x, Y0, z, r < 0.5 ? Material.COARSE_DIRT : r < 0.8 ? Material.GRAVEL : Material.DIRT_PATH);
            }
        for (int k = 0; k < 3; k++) {
            int z0 = zs[k];
            for (int x : new int[]{31, 35})
                for (int dz : new int[]{-2, 2}) for (int y = 1; y <= 3; y++) setP(x, Y0 + y, z0 + dz, Material.OAK_FENCE);
            for (int x = 31; x <= 35; x++)
                for (int z = z0 - 2; z <= z0 + 2; z++)
                    set(x, Y0 + 4, z, Math.floorMod(z - z0, 2) == 0 ? renk[k] : Material.WHITE_WOOL);
            for (int z = z0 - 2; z <= z0 + 2; z++) {
                set(32, Y0 + 1, z, Material.SPRUCE_PLANKS);
                Material[] mal = {Material.HAY_BLOCK, Material.MELON, Material.PUMPKIN, Material.CAULDRON, Material.HAY_BLOCK};
                set(34, Y0 + 1, z, mal[(z - z0 + 2) % 5]);
            }
            set(33, Y0 + 3, z0, fener(Material.LANTERN, true));
        }
    }

    private void kosk() {
        int cz = 34;
        for (int x = -7; x <= 7; x++)
            for (int z = cz - 7; z <= cz + 7; z++) {
                double d = Math.hypot(x, z - cz);
                if (d <= 5.6) set(x, Y0, z, d <= 2.3 ? Material.SMOOTH_QUARTZ : Material.POLISHED_DIORITE);
                if (d <= 6.4 && d > 5.6) set(x, Y0, z, Material.STONE_BRICKS);
            }
        for (int k = 0; k < 8; k++) {
            double a = Math.toRadians(k * 45);
            int px = (int) Math.round(Math.cos(a) * 4.7), pz = cz + (int) Math.round(Math.sin(a) * 4.7);
            for (int y = 1; y <= 5; y++) set(px, Y0 + y, pz, y == 1 || y == 5 ? Material.CHISELED_QUARTZ_BLOCK : Material.QUARTZ_PILLAR);
        }
        for (int x = -7; x <= 7; x++)
            for (int z = cz - 7; z <= cz + 7; z++) {
                double d = Math.hypot(x, z - cz);
                if (d <= 6.3) set(x, Y0 + 6, z, Material.QUARTZ_SLAB);
                if (d <= 3.4) set(x, Y0 + 7, z, Material.QUARTZ_SLAB);
            }
        set(0, Y0 + 5, cz, fener(Material.LANTERN, true));
        for (int k = 0; k < 3; k++) {
            double a = Math.toRadians(90 + 120 * k);
            int px = (int) Math.round(Math.cos(a) * 3.2), pz = cz + (int) Math.round(Math.sin(a) * 3.2);
            set(px, Y0 + 1, pz, Material.CHISELED_QUARTZ_BLOCK);
            set(px, Y0 + 2, pz, Material.END_ROD);
        }
    }

    private void kamp() {
        int cx = 24, cz = -24;
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) if (Math.hypot(dx, dz) <= 2.4) set(cx + dx, Y0, cz + dz, Material.COARSE_DIRT);
        set(cx, Y0 + 1, cz, Material.CAMPFIRE);
        set(cx + 3, Y0 + 1, cz, merdiven(Material.SPRUCE_STAIRS, BlockFace.WEST));
        set(cx - 3, Y0 + 1, cz, merdiven(Material.SPRUCE_STAIRS, BlockFace.EAST));
        set(cx, Y0 + 1, cz + 3, merdiven(Material.SPRUCE_STAIRS, BlockFace.NORTH));
        set(cx, Y0 + 1, cz - 3, merdiven(Material.SPRUCE_STAIRS, BlockFace.SOUTH));
        set(cx + 3, Y0 + 1, cz - 3, Material.HAY_BLOCK);
        set(cx + 3, Y0 + 1, cz - 2, Material.HAY_BLOCK);
        set(cx - 3, Y0 + 1, cz + 3, Material.BARREL);
    }

    private void kule() {
        int cx = -26, cz = -26;
        for (int x = cx - 2; x <= cx + 2; x++)
            for (int z = cz - 2; z <= cz + 2; z++)
                for (int y = 1; y <= 10; y++) {
                    boolean kose = Math.abs(x - cx) == 2 && Math.abs(z - cz) == 2;
                    Material m;
                    if (kose) m = Material.OAK_LOG;
                    else if (y % 4 == 0) m = Material.STONE_BRICKS;
                    else m = rnd.nextDouble() < 0.25 ? Material.MOSSY_COBBLESTONE : Material.COBBLESTONE;
                    set(x, Y0 + y, z, m);
                }
        for (int x = cx - 3; x <= cx + 3; x++)
            for (int z = cz - 3; z <= cz + 3; z++) {
                if (x == cx + 3 && z == cz) continue;
                set(x, Y0 + 11, z, Material.OAK_PLANKS);
            }
        BlockData merd = Bukkit.createBlockData(Material.LADDER);
        if (merd instanceof Directional dr) dr.setFacing(BlockFace.EAST);
        for (int y = 1; y <= 11; y++) set(cx + 3, Y0 + y, cz, merd);
        for (int x = cx - 3; x <= cx + 3; x++)
            for (int z = cz - 3; z <= cz + 3; z++) {
                boolean kenar = Math.abs(x - cx) == 3 || Math.abs(z - cz) == 3;
                if (!kenar || (x == cx + 3 && z == cz)) continue;
                setP(x, Y0 + 12, z, Material.OAK_FENCE);
            }
        for (int sx : new int[]{-3, 3}) for (int sz : new int[]{-3, 3}) {
            setP(cx + sx, Y0 + 13, cz + sz, Material.OAK_FENCE);
            set(cx + sx, Y0 + 14, cz + sz, fener(Material.LANTERN, false));
        }
        set(cx, Y0 + 12, cz, Material.CAMPFIRE);
    }

    private void iskele() {
        for (int x = -26; x <= -15; x++)
            for (int z = 22; z <= 23; z++) set(x, Y0, z, Material.OAK_PLANKS);
        for (int x : new int[]{-17, -21, -25}) {
            for (int z : new int[]{22, 23}) {
                int s = zemin(x, z);
                for (int y = Math.max(s + 1, 56); y <= 63; y++) setP(x, y, z, Material.OAK_FENCE);
            }
        }
        for (int y = 1; y <= 2; y++) setP(-26, Y0 + y, 22, Material.OAK_FENCE);
        set(-26, Y0 + 3, 22, fener(Material.LANTERN, false));
        // nilüfer
        for (int x = (int) (PX - PR); x <= PX + PR; x++)
            for (int z = (int) (PZ - PR); z <= PZ + PR; z++) {
                if (Math.hypot(x - PX, z - PZ) > PR - 2.5) continue;
                int s = zemin(x, z);
                if (s >= 63 || (z >= 22 && z <= 23 && x <= -15)) continue;
                if (rnd.nextDouble() < 0.14) set(x, Y0, z, Material.LILY_PAD);
            }
    }

    private void yolLambalari() {
        for (Seg sg : yollar) {
            double l = sg.uzun();
            double dx = (sg.bx - sg.ax) / l, dz = (sg.bz - sg.az) / l;
            int i = 0;
            for (double t = 7; t < l - 2; t += 9, i++) {
                double yan = (i % 2 == 0 ? 1 : -1) * 4.4;
                int x = (int) Math.round(sg.ax + dx * t - dz * yan), z = (int) Math.round(sg.az + dz * t + dx * yan);
                if (!yolda(x, z) && !padYakin(x, z, 0)) direk(x, z);
            }
        }
    }

    // ============================================================ ağaçlar

    private void yaprakKoy(int x, int y, int z, Material m) {
        Material mevcut = w.getBlockAt(x, y, z).getType();
        if (mevcut.isAir() || mevcut == Material.SHORT_GRASS || mevcut == Material.FERN || mevcut.name().endsWith("_LEAVES")) set(x, y, z, yaprak(m));
    }

    private void agacMese(int x, int z, boolean huse) {
        int s = zemin(x, z);
        int h = huse ? 5 + rnd.nextInt(3) : 4 + rnd.nextInt(3);
        Material kutuk = huse ? Material.BIRCH_LOG : Material.OAK_LOG;
        Material yap = huse ? Material.BIRCH_LEAVES : Material.OAK_LEAVES;
        for (int y = 1; y <= h; y++) set(x, s + y, z, kutuk);
        for (int dy = -2; dy <= 1; dy++) {
            int rad = dy <= -1 ? 2 : 1;
            for (int dx = -rad; dx <= rad; dx++)
                for (int dz = -rad; dz <= rad; dz++) {
                    if (Math.abs(dx) == rad && Math.abs(dz) == rad && (dy >= 0 || rnd.nextBoolean())) continue;
                    if (dx == 0 && dz == 0 && dy <= 0) continue;
                    yaprakKoy(x + dx, s + h + dy, z + dz, yap);
                }
        }
        set(x, s, z, Material.GRASS_BLOCK);
    }

    private void agacCam(int x, int z) {
        int s = zemin(x, z);
        int h = 7 + rnd.nextInt(3);
        for (int y = 1; y <= h; y++) set(x, s + y, z, Material.SPRUCE_LOG);
        for (int y = s + 3; y <= s + h + 1; y++) {
            int k = (s + h + 1) - y;
            double rad = Math.min(3, (k + 1) / 2.0 + (k % 2 == 0 ? 0 : 0.6));
            int ri = (int) Math.ceil(rad);
            for (int dx = -ri; dx <= ri; dx++)
                for (int dz = -ri; dz <= ri; dz++) {
                    if (dx * dx + dz * dz > rad * rad + 0.5) continue;
                    if (dx == 0 && dz == 0 && y <= s + h) continue;
                    yaprakKoy(x + dx, y, z + dz, Material.SPRUCE_LEAVES);
                }
        }
    }

    private void agacKiraz(int x, int z) {
        int s = zemin(x, z);
        int h = 4 + rnd.nextInt(2);
        for (int y = 1; y <= h; y++) set(x, s + y, z, Material.CHERRY_LOG);
        for (int dy = -1; dy <= 1; dy++) {
            double rad = dy == 1 ? 1.5 : 3.2;
            for (int dx = -3; dx <= 3; dx++)
                for (int dz = -3; dz <= 3; dz++) {
                    if (Math.hypot(dx, dz) > rad || (dx == 0 && dz == 0 && dy <= 0)) continue;
                    yaprakKoy(x + dx, s + h + dy, z + dz, Material.CHERRY_LEAVES);
                }
        }
    }

    private void agaclariKoy(int adet, int baslangic) {
        for (int i = baslangic; i < baslangic + adet && i < agaclar.size(); i++) {
            int[] a = agaclar.get(i);
            switch (a[2]) {
                case 0 -> agacMese(a[0], a[1], false);
                case 1 -> agacMese(a[0], a[1], true);
                case 2 -> agacCam(a[0], a[1]);
                default -> agacKiraz(a[0], a[1]);
            }
        }
    }

    private void agacPlanla() {
        // gölet çevresinde kiraz
        for (int k = 0; k < 7; k++) {
            double a = Math.toRadians(k * 51 + 10);
            double r = PR + 3.5 + rnd.nextInt(3);
            int x = (int) Math.round(PX + Math.cos(a) * r), z = (int) Math.round(PZ + Math.sin(a) * r);
            if (zemin(x, z) != YOK && !yolda(x, z) && !padYakin(x, z, -PR + 1)) agaclar.add(new int[]{x, z, 3});
        }
        for (int deneme = 0; deneme < 420 && agaclar.size() < 95; deneme++) {
            int x = rnd.nextInt(TARA * 2 - 6) - (TARA - 3), z = rnd.nextInt(TARA * 2 - 6) - (TARA - 3);
            double d = Math.hypot(x, z);
            if (d < 19 || zemin(x, z) == YOK || d > kenarR(x, z) - 4) continue;
            if (yolda(x, z) || padYakin(x, z, 3) || Math.hypot(x - PX, z - PZ) < PR + 4) continue;
            boolean yakin = false;
            for (int[] a : agaclar) if (Math.hypot(a[0] - x, a[1] - z) < 4.5) {
                yakin = true;
                break;
            }
            if (yakin) continue;
            double r = rnd.nextDouble();
            // dış halkada ladin ağırlıklı (orman hissi)
            int tur = d > 44 ? (r < 0.55 ? 2 : r < 0.8 ? 0 : 1) : (r < 0.55 ? 0 : r < 0.8 ? 1 : 2);
            agaclar.add(new int[]{x, z, tur});
        }
    }

    private void kayalar() {
        for (int k = 0; k < 14; k++) {
            int x = rnd.nextInt(TARA * 2 - 6) - (TARA - 3), z = rnd.nextInt(TARA * 2 - 6) - (TARA - 3);
            if (zemin(x, z) == YOK || Math.hypot(x, z) < 20 || yolda(x, z) || padYakin(x, z, 3)) continue;
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++) {
                    int s = zemin(x + dx, z + dz);
                    if (s == YOK || Math.hypot(dx, dz) > 1.2 || (dx != 0 && dz != 0 && rnd.nextBoolean())) continue;
                    set(x + dx, s + 1, z + dz, rnd.nextBoolean() ? Material.MOSSY_COBBLESTONE : Material.COBBLESTONE);
                    if (dx == 0 && dz == 0) set(x, s + 2, z, Material.MOSSY_COBBLESTONE);
                }
        }
    }

    // ============================================================ çalıştır

    void baslat(Player yonetici) {
        List<int[]> kolonlar = new ArrayList<>();
        for (int x = -TARA; x <= TARA; x++) for (int z = -TARA; z <= TARA; z++) if (zemin(x, z) != YOK) kolonlar.add(new int[]{x, z});
        agacPlanla();

        List<Runnable> adimlar = new ArrayList<>();
        adimlar.add(this::cesme);
        adimlar.add(this::meydanSusu);
        adimlar.add(this::kapi);
        adimlar.add(this::pazar);
        adimlar.add(this::kosk);
        adimlar.add(this::kamp);
        adimlar.add(this::kule);
        adimlar.add(this::iskele);
        adimlar.add(this::yolLambalari);
        for (int i = 0; i < agaclar.size(); i += 8) {
            final int b = i;
            adimlar.add(() -> agaclariKoy(8, b));
        }
        adimlar.add(this::kayalar);

        final int toplam = kolonlar.size() + adimlar.size() * 40;
        new BukkitRunnable() {
            int ki = 0, ai = 0, sonYuzde = -1;

            @Override
            public void run() {
                try {
                    int say = 0;
                    while (ki < kolonlar.size() && say < 90) {
                        int[] k = kolonlar.get(ki++);
                        kolon(k[0], k[1]);
                        say++;
                    }
                    if (ki >= kolonlar.size() && say == 0) {
                        if (ai < adimlar.size()) adimlar.get(ai++).run();
                        else {
                            cancel();
                            bitir(yonetici);
                            return;
                        }
                    }
                    int yuzde = Math.min(99, (int) ((ki + ai * 40L) * 100L / toplam));
                    if (yuzde / 20 != sonYuzde / 20 && yonetici.isOnline()) {
                        sonYuzde = yuzde;
                        yonetici.sendMessage("§8[§bSpawn§8] §7Kuruluyor... §f%" + yuzde);
                    }
                } catch (RuntimeException e) {
                    cancel();
                    pl.getLogger().severe("Spawn kurulum hatası: " + e);
                    if (yonetici.isOnline()) yonetici.sendMessage("§cSpawn kurulurken hata oluştu: " + e.getMessage());
                }
            }
        }.runTaskTimer(pl, 1L, 1L);
    }

    private void bitir(Player yonetici) {
        Location s = new Location(w, 0.5, Y0 + 1, 9.5, 180f, 0f);
        pl.spawnAyarla(s);
        pl.spawnDunyaAyar(w);
        if (yonetici.isOnline()) {
            yonetici.teleport(s);
            yonetici.sendMessage("§8[§bSpawn§8] §aSpawn hazır! §7Meydan, çeşme, Zindan Kapısı (kuzey), pazar (doğu), Kasalar köşkü (güney), "
                    + "gölet ve iskele (güneybatı), kamp (kuzeydoğu) ve gözlem kulesi (kuzeybatı) var. §f/spawn §7artık burayı gösteriyor.");
        }
    }
}
