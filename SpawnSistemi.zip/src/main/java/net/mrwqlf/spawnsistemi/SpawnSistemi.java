package net.mrwqlf.spawnsistemi;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Difficulty;
import org.bukkit.WorldCreator;
import org.bukkit.WorldType;
import org.bukkit.block.Biome;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;
import java.util.Random;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;
import java.util.UUID;
import java.util.regex.Pattern;

public final class SpawnSistemi extends JavaPlugin implements Listener, TabExecutor {
    private static final Pattern AD = Pattern.compile("[a-zA-Z0-9_\\-]{1,16}");

    /** Özel depo envanteri sahibi. */
    static final class PvHolder implements InventoryHolder {
        final UUID sahip;
        final int no;
        Inventory inv;

        PvHolder(UUID sahip, int no) {
            this.sahip = sahip;
            this.no = no;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    /** /pv numara seçme menüsü. */
    static final class PvMenu implements InventoryHolder {
        Inventory inv;
        int adet;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    /** Boş (void) dünya üreticisi: arazi SpawnInsa tarafından kodla kurulur. */
    static final class BosUretec extends ChunkGenerator {
        @Override
        public Location getFixedSpawnLocation(World w, Random r) {
            return new Location(w, 0.5, 65, 9.5);
        }
    }

    /** Her yer ova biyomu: çim/yaprak rengi tutarlı olsun. */
    static final class OvaBiyom extends BiomeProvider {
        @Override
        public Biome getBiome(WorldInfo wi, int x, int y, int z) {
            return Biome.PLAINS;
        }

        @Override
        public List<Biome> getBiomes(WorldInfo wi) {
            return List.of(Biome.PLAINS);
        }
    }

    static final String SPAWN_DUNYA = "spawn";

    private File veriDosya;
    private YamlConfiguration veri;
    private File pvKlasor;
    private final Map<UUID, BukkitTask> bekleyen = new HashMap<>();
    /** Açık depolar: aynı depoyu birden fazla kişi (sahip + yönetici) aynı envanterle görür, çiftleme olmaz. */
    private final Map<String, Inventory> acikPv = new HashMap<>();

    // ================================================================== yaşam döngüsü

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getConfig().options().copyDefaults(true);
        saveConfig();
        veriDosya = new File(getDataFolder(), "veri.yml");
        veri = YamlConfiguration.loadConfiguration(veriDosya);
        pvKlasor = new File(getDataFolder(), "pv");
        //noinspection ResultOfMethodCallIgnored
        pvKlasor.mkdirs();
        Bukkit.getPluginManager().registerEvents(this, this);
        if (veri.getBoolean("spawn-dunya-kuruldu", false)) {
            World sw = spawnDunyasiYukle();
            if (sw != null) spawnDunyaAyar(sw);
        }
        // spawn dünyası hep gündüz + açık hava
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            World sw = Bukkit.getWorld(SPAWN_DUNYA);
            if (sw != null) {
                sw.setTime(6000);
                sw.setStorm(false);
            }
        }, 100L, 600L);
        for (String c : new String[]{"spawnkur", "spawn", "setspawn", "warp", "setwarp", "delwarp", "sethome", "home", "delhome", "pv", "pvbak"}) {
            var cmd = getCommand(c);
            if (cmd != null) {
                cmd.setExecutor(this);
                cmd.setTabCompleter(this);
            }
        }
        getLogger().info("SpawnSistemi etkin.");
    }

    @Override
    public void onDisable() {
        for (Player p : new ArrayList<>(Bukkit.getOnlinePlayers())) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof PvHolder) p.closeInventory();
        }
        for (Map.Entry<String, Inventory> e : new HashMap<>(acikPv).entrySet()) {
            if (e.getValue().getHolder() instanceof PvHolder h) pvKaydet(h, e.getValue());
        }
        acikPv.clear();
        kaydet();
    }

    private void kaydet() {
        try {
            veri.save(veriDosya);
        } catch (IOException e) {
            getLogger().warning("veri.yml yazılamadı: " + e.getMessage());
        }
    }

    private static void msj(CommandSender s, String m) {
        s.sendMessage(LegacyComponentSerializer.legacySection().deserialize("§8[§bSpawn§8] §r" + m));
    }

    // ================================================================== konum saklama

    private void konumYaz(String yol, Location l) {
        veri.set(yol + ".w", l.getWorld().getName());
        veri.set(yol + ".x", l.getX());
        veri.set(yol + ".y", l.getY());
        veri.set(yol + ".z", l.getZ());
        veri.set(yol + ".yaw", l.getYaw());
        veri.set(yol + ".pitch", l.getPitch());
    }

    private Location konumOku(String yol) {
        if (!veri.contains(yol + ".w")) return null;
        World w = Bukkit.getWorld(veri.getString(yol + ".w", ""));
        if (w == null) return null;
        return new Location(w, veri.getDouble(yol + ".x"), veri.getDouble(yol + ".y"), veri.getDouble(yol + ".z"),
                (float) veri.getDouble(yol + ".yaw"), (float) veri.getDouble(yol + ".pitch"));
    }

    private boolean yasakDunya(World w) {
        return w != null && getConfig().getStringList("yasak-dunyalar").contains(w.getName());
    }

    // ================================================================== ışınlanma (geri sayım)

    private void isinla(Player p, Location hedef, String ad) {
        if (yasakDunya(p.getWorld())) {
            msj(p, "§cBu dünyada ışınlanma kullanılamaz.");
            return;
        }
        int sn = p.hasPermission("spawnsistemi.bekleme-yok") ? 0 : getConfig().getInt("bekleme-sn", 3);
        iptal(p, false);
        if (sn <= 0) {
            git(p, hedef, ad);
            return;
        }
        final Location bas = p.getLocation().clone();
        msj(p, "§e" + ad + " §7konumuna §e" + sn + " sn §7içinde ışınlanacaksın. §cHareket etme!");
        BukkitTask t = new BukkitRunnable() {
            int kalan = sn;

            @Override
            public void run() {
                if (!p.isOnline()) {
                    cancel();
                    bekleyen.remove(p.getUniqueId());
                    return;
                }
                Location c = p.getLocation();
                if (c.getWorld() != bas.getWorld() || c.distanceSquared(bas) > 0.6) {
                    cancel();
                    bekleyen.remove(p.getUniqueId());
                    msj(p, "§cHareket ettiğin için ışınlanma iptal edildi.");
                    return;
                }
                if (--kalan <= 0) {
                    cancel();
                    bekleyen.remove(p.getUniqueId());
                    git(p, hedef, ad);
                }
            }
        }.runTaskTimer(this, 20L, 20L);
        bekleyen.put(p.getUniqueId(), t);
    }

    private void iptal(Player p, boolean bildir) {
        BukkitTask t = bekleyen.remove(p.getUniqueId());
        if (t != null) {
            t.cancel();
            if (bildir) msj(p, "§cIşınlanma iptal edildi.");
        }
    }

    private void git(Player p, Location hedef, String ad) {
        p.teleport(hedef);
        p.setFallDistance(0);
        p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.8f, 1.2f);
        msj(p, "§a" + ad + " §7konumuna ışınlandın.");
    }

    @EventHandler(ignoreCancelled = true)
    public void onHasar(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && bekleyen.containsKey(p.getUniqueId())) iptal(p, true);
    }

    // ================================================================== olaylar: spawn

    @EventHandler
    public void onGiris(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!p.hasPlayedBefore() && getConfig().getBoolean("ilk-giriste-spawn", true)) {
            Location s = spawnKonumu();
            if (s != null) Bukkit.getScheduler().runTaskLater(this, () -> {
                if (p.isOnline()) p.teleport(s);
            }, 5L);
        }
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onYenidenDogma(PlayerRespawnEvent e) {
        if (!getConfig().getBoolean("olunce-spawn", true)) return;
        if (e.isBedSpawn() || e.isAnchorSpawn()) return;
        World rw = e.getRespawnLocation().getWorld();
        if (e.getPlayer().getWorld().getName().startsWith("zindan_") || (rw != null && rw.getName().startsWith("zindan_"))) return;
        Location s = spawnKonumu();
        if (s != null) e.setRespawnLocation(s);
    }

    @EventHandler
    public void onCik(PlayerQuitEvent e) {
        iptal(e.getPlayer(), false);
    }

    // ================================================================== spawn dünyası

    World spawnDunyasiYukle() {
        World w = Bukkit.getWorld(SPAWN_DUNYA);
        if (w != null) return w;
        return new WorldCreator(SPAWN_DUNYA)
                .generator(new BosUretec())
                .biomeProvider(new OvaBiyom())
                .type(WorldType.NORMAL)
                .generateStructures(false)
                .createWorld();
    }

    void spawnDunyaAyar(World w) {
        w.setDifficulty(Difficulty.PEACEFUL);
        w.setSpawnFlags(false, false);
        w.setTime(6000);
        w.setStorm(false);
        w.getWorldBorder().setCenter(0, 0);
        w.getWorldBorder().setSize(84);
        w.setAutoSave(true);
    }

    void spawnAyarla(Location l) {
        konumYaz("spawn", l);
        veri.set("spawn-dunya-kuruldu", true);
        kaydet();
        l.getWorld().setSpawnLocation(l);
    }

    private boolean spawnDunyasi(World w) {
        return w != null && w.getName().equals(SPAWN_DUNYA);
    }

    private boolean yapiYetkili(Player p) {
        return p.hasPermission("spawnsistemi.admin") && p.getGameMode() == org.bukkit.GameMode.CREATIVE;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onSpawnKir(BlockBreakEvent e) {
        if (spawnDunyasi(e.getBlock().getWorld()) && !yapiYetkili(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onSpawnKoy(BlockPlaceEvent e) {
        if (spawnDunyasi(e.getBlock().getWorld()) && !yapiYetkili(e.getPlayer())) e.setCancelled(true);
    }

    /** Spawn'da PvP, hasar ve açlık yok (boşluğa düşme hariç — aşağıda spawn'a geri alınır). */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onSpawnHasar(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p) || !spawnDunyasi(p.getWorld())) return;
        if (e.getCause() == EntityDamageEvent.DamageCause.VOID || e.getCause() == EntityDamageEvent.DamageCause.KILL
                || e.getCause() == EntityDamageEvent.DamageCause.SUICIDE) return;
        e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onSpawnVurus(EntityDamageByEntityEvent e) {
        if (e.getEntity() instanceof Player p && spawnDunyasi(p.getWorld()) && e.getDamager() instanceof Player) e.setCancelled(true);
    }

    @EventHandler
    public void onSpawnAclik(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && spawnDunyasi(p.getWorld())) e.setCancelled(true);
    }

    @EventHandler
    public void onSpawnDus(PlayerMoveEvent e) {
        if (e.getTo() == null || e.getTo().getY() >= 30 || !spawnDunyasi(e.getTo().getWorld())) return;
        Location s = spawnKonumu();
        if (s != null) {
            e.getPlayer().setFallDistance(0);
            e.getPlayer().teleport(s);
        }
    }

    private Location spawnKonumu() {
        return konumOku("spawn");
    }

    // ================================================================== sağlayıcı: TagSistemi hakları

    private int tagHakki(UUID id, String metot) {
        Plugin t = Bukkit.getPluginManager().getPlugin("TagSistemi");
        if (t == null || !t.isEnabled()) return -1;
        try {
            Method m = t.getClass().getMethod(metot, UUID.class);
            return (int) m.invoke(t, id);
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return -1;
        }
    }

    /** Oyuncunun home hakkı: rütbe ayarı > yetkili varsayılanı > genel varsayılan. */
    public int homeHakki(Player p) {
        int v = tagHakki(p.getUniqueId(), "homeLimiti");
        if (v == Integer.MAX_VALUE) v = getConfig().getInt("yetkili-home", 20);
        return Math.max(getConfig().getInt("varsayilan-home", 1), v);
    }

    public int pvHakki(Player p) {
        int v = tagHakki(p.getUniqueId(), "pvLimiti");
        if (v == Integer.MAX_VALUE) v = getConfig().getInt("yetkili-pv", 10);
        int maks = Math.max(1, Math.min(54, getConfig().getInt("maks-pv", 54)));
        return Math.min(maks, Math.max(getConfig().getInt("varsayilan-pv", 1), v));
    }

    // ================================================================== komutlar

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String ad = c.getName().toLowerCase(Locale.ROOT);
        switch (ad) {
            case "spawn" -> {
                if (!(s instanceof Player p)) return true;
                Location l = spawnKonumu();
                if (l == null) {
                    msj(p, "§cSpawn henüz ayarlanmamış. Yetkili §f/setspawn §cyazmalı.");
                    return true;
                }
                isinla(p, l, "Spawn");
            }
            case "spawnkur" -> {
                if (!(s instanceof Player p)) return true;
                World sw = spawnDunyasiYukle();
                if (sw == null) {
                    msj(p, "§cSpawn dünyası oluşturulamadı (konsolu kontrol et).");
                    return true;
                }
                spawnDunyaAyar(sw);
                long tohum = getConfig().getLong("spawn-tohum", 20261118L);
                msj(p, "§aSpawn adası kuruluyor (yaklaşık 1-2 dk, sunucu donmaz). §7Tohum: " + tohum + " §8(config: spawn-tohum)");
                new SpawnInsa(this, sw, tohum).baslat(p);
            }
            case "setspawn" -> {
                if (!(s instanceof Player p)) return true;
                konumYaz("spawn", p.getLocation());
                kaydet();
                msj(p, "§aSpawn bulunduğun konuma ayarlandı.");
                p.getWorld().setSpawnLocation(p.getLocation());
            }
            case "warp" -> warp(s, a);
            case "setwarp" -> {
                if (!(s instanceof Player p)) return true;
                if (a.length < 1 || !AD.matcher(a[0]).matches()) {
                    msj(p, "§c/setwarp <isim>  §7(harf, rakam, - ve _ ; en çok 16 karakter)");
                    return true;
                }
                konumYaz("warp." + a[0].toLowerCase(Locale.ROOT), p.getLocation());
                kaydet();
                msj(p, "§aWarp kaydedildi: §f" + a[0].toLowerCase(Locale.ROOT) + " §7(/warp " + a[0].toLowerCase(Locale.ROOT) + ")");
            }
            case "delwarp" -> {
                if (a.length < 1) {
                    msj(s, "§c/delwarp <isim>");
                    return true;
                }
                String k = a[0].toLowerCase(Locale.ROOT);
                if (!veri.contains("warp." + k)) {
                    msj(s, "§cBöyle bir warp yok.");
                    return true;
                }
                veri.set("warp." + k, null);
                kaydet();
                msj(s, "§aWarp silindi: §f" + k);
            }
            case "sethome" -> {
                if (!(s instanceof Player p)) return true;
                setHome(p, a);
            }
            case "home" -> {
                if (!(s instanceof Player p)) return true;
                if (label.equalsIgnoreCase("homes")) {
                    ConfigurationSection ev = evler(p);
                    if (ev == null || ev.getKeys(false).isEmpty()) msj(p, "§7Hiç home'un yok. §f/sethome §7ile belirle.");
                    else listeHome(p, ev);
                    return true;
                }
                home(p, a);
            }
            case "delhome" -> {
                if (!(s instanceof Player p)) return true;
                if (a.length < 1) {
                    msj(p, "§c/delhome <isim>");
                    return true;
                }
                String k = a[0].toLowerCase(Locale.ROOT);
                String yol = "home." + p.getUniqueId() + "." + k;
                if (!veri.contains(yol)) {
                    msj(p, "§cBöyle bir home yok.");
                    return true;
                }
                veri.set(yol, null);
                kaydet();
                msj(p, "§aHome silindi: §f" + k);
            }
            case "pv" -> {
                if (!(s instanceof Player p)) return true;
                pvKomut(p, a);
            }
            case "pvbak" -> {
                if (!(s instanceof Player p)) return true;
                if (a.length < 1) {
                    msj(p, "§c/pvbak <oyuncu> [numara]");
                    return true;
                }
                @SuppressWarnings("deprecation")
                var hedef = Bukkit.getOfflinePlayer(a[0]);
                int no = 1;
                try {
                    if (a.length >= 2) no = Integer.parseInt(a[1]);
                } catch (NumberFormatException e) {
                    msj(p, "§cNumara sayı olmalı.");
                    return true;
                }
                if (no < 1 || no > 54) {
                    msj(p, "§cNumara 1-54.");
                    return true;
                }
                pvAc(p, hedef.getUniqueId(), no, hedef.getName() == null ? a[0] : hedef.getName());
            }
            default -> {
                return false;
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ warp

    private void warp(CommandSender s, String[] a) {
        ConfigurationSection w = veri.getConfigurationSection("warp");
        if (a.length == 0) {
            if (w == null || w.getKeys(false).isEmpty()) {
                msj(s, "§7Henüz warp yok.");
                return;
            }
            Component satir = Component.text("Warplar: ").color(net.kyori.adventure.text.format.NamedTextColor.GRAY);
            boolean ilk = true;
            for (String k : new TreeSet<>(w.getKeys(false))) {
                if (!ilk) satir = satir.append(Component.text(", ", net.kyori.adventure.text.format.NamedTextColor.DARK_GRAY));
                ilk = false;
                satir = satir.append(Component.text(k, net.kyori.adventure.text.format.NamedTextColor.AQUA)
                        .clickEvent(ClickEvent.runCommand("/warp " + k))
                        .hoverEvent(HoverEvent.showText(Component.text("Tıkla: /warp " + k))));
            }
            s.sendMessage(satir);
            return;
        }
        if (!(s instanceof Player p)) return;
        String k = a[0].toLowerCase(Locale.ROOT);
        Location l = konumOku("warp." + k);
        if (l == null) {
            msj(p, "§cBöyle bir warp yok. §7(/warp)");
            return;
        }
        isinla(p, l, "Warp " + k);
    }

    // ------------------------------------------------------------------ home

    private ConfigurationSection evler(Player p) {
        return veri.getConfigurationSection("home." + p.getUniqueId());
    }

    private void setHome(Player p, String[] a) {
        if (yasakDunya(p.getWorld())) {
            msj(p, "§cBu dünyada home ayarlanamaz.");
            return;
        }
        String k = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "home";
        if (!AD.matcher(k).matches()) {
            msj(p, "§c/sethome [isim]  §7(harf, rakam, - ve _ ; en çok 16 karakter)");
            return;
        }
        ConfigurationSection ev = evler(p);
        int mevcut = ev == null ? 0 : ev.getKeys(false).size();
        boolean var = ev != null && ev.contains(k);
        int hak = homeHakki(p);
        if (!var && mevcut >= hak) {
            msj(p, "§cHome hakkın dolu (§f" + mevcut + "/" + hak + "§c). Birini §f/delhome §csil ya da rütbeni yükselt.");
            return;
        }
        konumYaz("home." + p.getUniqueId() + "." + k, p.getLocation());
        kaydet();
        msj(p, "§aHome kaydedildi: §f" + k + " §7(" + (var ? mevcut : mevcut + 1) + "/" + hak + ")");
    }

    private void home(Player p, String[] a) {
        ConfigurationSection ev = evler(p);
        if (ev == null || ev.getKeys(false).isEmpty()) {
            msj(p, "§7Hiç home'un yok. §f/sethome §7ile belirle.");
            return;
        }
        String k;
        if (a.length > 0) k = a[0].toLowerCase(Locale.ROOT);
        else if (ev.contains("home")) k = "home";
        else if (ev.getKeys(false).size() == 1) k = ev.getKeys(false).iterator().next();
        else {
            listeHome(p, ev);
            return;
        }
        Location l = konumOku("home." + p.getUniqueId() + "." + k);
        if (l == null) {
            if (!ev.contains(k)) msj(p, "§cBöyle bir home yok.");
            else msj(p, "§cBu home'un dünyası şu an yüklü değil.");
            listeHome(p, ev);
            return;
        }
        isinla(p, l, "Home " + k);
    }

    private void listeHome(Player p, ConfigurationSection ev) {
        Component satir = Component.text("Home'ların (" + ev.getKeys(false).size() + "/" + homeHakki(p) + "): ",
                net.kyori.adventure.text.format.NamedTextColor.GRAY);
        boolean ilk = true;
        for (String k : new TreeSet<>(ev.getKeys(false))) {
            if (!ilk) satir = satir.append(Component.text(", ", net.kyori.adventure.text.format.NamedTextColor.DARK_GRAY));
            ilk = false;
            satir = satir.append(Component.text(k, net.kyori.adventure.text.format.NamedTextColor.GREEN)
                    .clickEvent(ClickEvent.runCommand("/home " + k))
                    .hoverEvent(HoverEvent.showText(Component.text("Tıkla: /home " + k))));
        }
        p.sendMessage(satir);
    }

    // ================================================================== özel depo (pv)

    private void pvKomut(Player p, String[] a) {
        int hak = pvHakki(p);
        if (a.length >= 1) {
            int no;
            try {
                no = Integer.parseInt(a[0]);
            } catch (NumberFormatException e) {
                msj(p, "§c/pv [numara]");
                return;
            }
            if (no < 1 || no > hak) {
                msj(p, "§cDepo hakkın: §f" + hak + "§c. §7Rütbeni yükselterek daha fazla depo alabilirsin.");
                return;
            }
            pvAc(p, p.getUniqueId(), no, null);
            return;
        }
        if (hak == 1) {
            pvAc(p, p.getUniqueId(), 1, null);
            return;
        }
        PvMenu m = new PvMenu();
        m.adet = hak;
        int satir = (hak + 8) / 9;
        Inventory inv = Bukkit.createInventory(m, satir * 9, "§5Özel Depolar");
        m.inv = inv;
        for (int i = 0; i < hak; i++) {
            ItemStack it = new ItemStack(Material.CHEST);
            ItemMeta im = it.getItemMeta();
            im.setDisplayName("§aDepo #" + (i + 1));
            int dolu = pvDoluSayisi(p.getUniqueId(), i + 1);
            im.setLore(List.of("§7Dolu slot: §f" + dolu + "/36", "§eTıkla ve aç"));
            it.setItemMeta(im);
            inv.setItem(i, it);
        }
        p.openInventory(inv);
    }

    private File pvDosya(UUID id) {
        return new File(pvKlasor, id + ".yml");
    }

    private int pvDoluSayisi(UUID id, int no) {
        File f = pvDosya(id);
        if (!f.exists()) return 0;
        int n = 0;
        for (String s : YamlConfiguration.loadConfiguration(f).getStringList("depo." + no)) if (!s.isEmpty()) n++;
        return n;
    }

    private void pvAc(Player izleyen, UUID sahip, int no, String sahipAdi) {
        String key = sahip + ":" + no;
        Inventory inv = acikPv.get(key);
        if (inv == null) {
            PvHolder h = new PvHolder(sahip, no);
            String baslik = "§5Depo #" + no + (sahipAdi != null ? " §7(" + sahipAdi + ")" : "");
            inv = Bukkit.createInventory(h, 36, baslik);
            h.inv = inv;
            File f = pvDosya(sahip);
            if (f.exists()) {
                List<String> l = YamlConfiguration.loadConfiguration(f).getStringList("depo." + no);
                for (int i = 0; i < l.size() && i < 36; i++) {
                    String s = l.get(i);
                    if (s.isEmpty()) continue;
                    try {
                        inv.setItem(i, ItemStack.deserializeBytes(Base64.getDecoder().decode(s)));
                    } catch (RuntimeException ex) {
                        getLogger().warning("Depo eşyası okunamadı (" + sahip + " #" + no + " slot " + i + "): " + ex.getMessage());
                    }
                }
            }
            acikPv.put(key, inv);
        }
        izleyen.openInventory(inv);
        izleyen.playSound(izleyen.getLocation(), Sound.BLOCK_ENDER_CHEST_OPEN, 0.8f, 1f);
    }

    private void pvKaydet(PvHolder h, Inventory inv) {
        File f = pvDosya(h.sahip);
        YamlConfiguration y = f.exists() ? YamlConfiguration.loadConfiguration(f) : new YamlConfiguration();
        List<String> l = new ArrayList<>();
        for (int i = 0; i < 36; i++) {
            ItemStack it = inv.getItem(i);
            l.add(it == null || it.getType().isAir() ? "" : Base64.getEncoder().encodeToString(it.serializeAsBytes()));
        }
        y.set("depo." + h.no, l);
        try {
            y.save(f);
        } catch (IOException e) {
            getLogger().severe("Depo kaydedilemedi (" + h.sahip + " #" + h.no + "): " + e.getMessage());
        }
    }

    @EventHandler
    public void onPvKapat(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof PvHolder h)) return;
        Inventory inv = e.getInventory();
        pvKaydet(h, inv);                           // her kapanışta kaydet (çökme/ani kapanışta kayıp olmasın)
        if (inv.getViewers().size() <= 1) acikPv.remove(h.sahip + ":" + h.no);
        if (e.getPlayer() instanceof Player p) p.playSound(p.getLocation(), Sound.BLOCK_ENDER_CHEST_CLOSE, 0.8f, 1f);
    }

    @EventHandler
    public void onMenuTik(InventoryClickEvent e) {
        if (e.getInventory().getHolder() instanceof PvMenu m) {
            e.setCancelled(true);
            if (e.getClickedInventory() != e.getInventory() || !(e.getWhoClicked() instanceof Player p)) return;
            int s = e.getRawSlot();
            if (s >= 0 && s < m.adet && s < pvHakki(p)) {
                p.closeInventory();
                pvAc(p, p.getUniqueId(), s + 1, null);
            }
        }
    }

    // ================================================================== tab tamamlama

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String alias, String[] a) {
        List<String> r = new ArrayList<>();
        String ad = c.getName().toLowerCase(Locale.ROOT);
        if (a.length == 1) {
            switch (ad) {
                case "warp", "delwarp" -> {
                    ConfigurationSection w = veri.getConfigurationSection("warp");
                    if (w != null) r.addAll(w.getKeys(false));
                }
                case "home", "delhome" -> {
                    if (s instanceof Player p && evler(p) != null) r.addAll(evler(p).getKeys(false));
                }
                case "pvbak" -> Bukkit.getOnlinePlayers().forEach(p -> r.add(p.getName()));
                default -> {
                }
            }
        }
        String son = a.length == 0 ? "" : a[a.length - 1].toLowerCase(Locale.ROOT);
        r.removeIf(x -> !x.toLowerCase(Locale.ROOT).startsWith(son));
        return r;
    }
}
